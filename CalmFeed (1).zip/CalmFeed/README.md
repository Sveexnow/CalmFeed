# CalmFeed

A free, personal-use Android app that opens Instagram, YouTube and Facebook
**without Reels and Shorts**, counts how long you spend, and stops you when you
hit your daily limit. X and Reddit are included for time tracking only.

No account, no ads, no payments, no data leaves your phone (time stats are
stored locally).

## What it does

- Opens each site in its own in-app browser and removes the short-video feeds:
  - Instagram: Reels tab and `/reels`, `/reel/` links
  - YouTube: Shorts shelves, the Shorts tab, `/shorts` links
  - Facebook: Reels and Watch
  - Tapping or navigating to a blocked page sends you back to the home feed.
- Daily limit across all apps (default 60 min, change it on the home screen).
  When it's reached the app shows a "limit reached" screen.
- Time per app per day and a 7-day chart.

## Honest limitations

- These are the **websites** inside a WebView, not the official apps, so some
  features are missing (posting from Instagram web, for example).
- Google blocks sign-in inside WebViews, so YouTube may not let you log in.
  It still works signed out.
- Sites change their markup. If Shorts/Reels show up again someday, edit
  `Apps.kt` (paths and CSS) or `assets/blocker.js`.
- The limit is only a speed bump: you can raise it on the home screen, and
  you can still open the real apps. For a harder block, also uninstall the
  official apps and keep only CalmFeed.

## Getting the APK (free)

### Option A: GitHub, no Android Studio needed
1. Make a free account at github.com and create a new repository.
2. Upload everything in this folder (keep the folder structure, including
   `.github/workflows/build.yml`).
3. Open the **Actions** tab, pick **Build APK**, and wait ~5 minutes
   (it also starts automatically after the upload).
4. Open the finished run, download **CalmFeed-apk**, unzip, and you have
   `app-debug.apk`.

### Option B: Android Studio
1. Install Android Studio (free), choose **Open**, select this folder.
2. Let Gradle sync, then **Build > Build APK(s)**.
3. The file is at `app/build/outputs/apk/debug/app-debug.apk`.

## Installing

Copy `app-debug.apk` to your phone and open it. Android will ask to allow
installing from that source (Files or Chrome): allow it just for this install.
Play Protect may say the app is unrecognized because it isn't from the Play
Store; that's expected for apps you build yourself.
