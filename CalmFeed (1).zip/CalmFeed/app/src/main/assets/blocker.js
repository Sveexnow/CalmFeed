(function () {
  if (window.__calmfeed) return;
  window.__calmfeed = true;

  // Replaced by the app before injection.
  var BLOCKED = __PATHS__;
  var HOME = __HOME__;
  var CSS = __CSS__;

  // When a blocked link is found, hide the nav item / card that contains it.
  var HIDE_PARENTS =
    'ytm-pivot-bar-item-renderer, ytm-shorts-lockup-view-model, ' +
    'ytm-shorts-lockup-view-model-v2, ytm-reel-item-renderer, li';

  var style = document.createElement('style');
  style.textContent = CSS;
  (document.head || document.documentElement).appendChild(style);

  function blockedPath(p) {
    for (var i = 0; i < BLOCKED.length; i++) {
      if (p.indexOf(BLOCKED[i]) === 0) return true;
    }
    return false;
  }

  function pathOf(href) {
    try {
      return new URL(href, location.href).pathname;
    } catch (e) {
      return null;
    }
  }

  function sweep() {
    if (blockedPath(location.pathname)) {
      location.replace(HOME);
      return;
    }
    var links = document.querySelectorAll('a[href]');
    for (var i = 0; i < links.length; i++) {
      var a = links[i];
      var href = a.getAttribute('href');
      if (a.__cfHref === href) continue;
      a.__cfHref = href;
      var p = pathOf(href);
      if (p && blockedPath(p)) {
        var target = a.closest(HIDE_PARENTS) || a;
        target.style.setProperty('display', 'none', 'important');
      }
    }
  }

  // Stop taps on blocked links before the site's own code sees them.
  document.addEventListener(
    'click',
    function (e) {
      var a = e.target && e.target.closest ? e.target.closest('a[href]') : null;
      if (!a) return;
      var p = pathOf(a.getAttribute('href'));
      if (p && blockedPath(p)) {
        e.preventDefault();
        e.stopPropagation();
      }
    },
    true
  );

  var pending = false;
  function schedule() {
    if (pending) return;
    pending = true;
    setTimeout(function () {
      pending = false;
      sweep();
    }, 250);
  }

  new MutationObserver(schedule).observe(document.documentElement, {
    childList: true,
    subtree: true
  });
  setInterval(sweep, 1000);
  sweep();
})();
