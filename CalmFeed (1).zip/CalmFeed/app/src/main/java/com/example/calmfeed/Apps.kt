package com.example.calmfeed

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * One entry per site CalmFeed can open.
 *
 * To block more (or less), edit [blockedPaths] (URL path prefixes that get
 * redirected home and whose links get hidden) and [hideCss] (extra elements
 * to hide). Sites change their markup now and then, so these may need small
 * updates over time.
 */
data class SocialApp(
    val id: String,
    val name: String,
    val startUrl: String,
    val hosts: List<String>,
    val blockedPaths: List<String> = emptyList(),
    val hideCss: String = ""
) {
    fun isBlockedPath(path: String) = blockedPaths.any { path.startsWith(it) }

    fun isAllowedHost(host: String?): Boolean {
        if (host == null) return false
        return hosts.any { host == it || host.endsWith(".$it") }
    }
}

object Apps {
    val all = listOf(
        SocialApp(
            id = "instagram",
            name = "Instagram",
            startUrl = "https://www.instagram.com/",
            hosts = listOf("instagram.com", "facebook.com", "meta.com", "fb.com"),
            blockedPaths = listOf("/reels", "/reel/"),
            hideCss = "a[href^=\"/reels\"], a[href^=\"/reel/\"] { display: none !important; }"
        ),
        SocialApp(
            id = "youtube",
            name = "YouTube",
            startUrl = "https://m.youtube.com/",
            hosts = listOf("youtube.com", "youtu.be", "google.com"),
            blockedPaths = listOf("/shorts"),
            hideCss = "ytm-reel-shelf-renderer, ytm-shorts-lockup-view-model, " +
                "ytm-shorts-lockup-view-model-v2, ytm-reel-item-renderer, " +
                "a[href^=\"/shorts\"] { display: none !important; }"
        ),
        SocialApp(
            id = "facebook",
            name = "Facebook",
            startUrl = "https://m.facebook.com/",
            hosts = listOf("facebook.com", "fb.com"),
            blockedPaths = listOf("/reel", "/reels", "/watch"),
            hideCss = "a[href^=\"/reel\"], a[href^=\"/watch\"] { display: none !important; }"
        ),
        SocialApp(
            id = "x",
            name = "X",
            startUrl = "https://x.com/",
            hosts = listOf("x.com", "twitter.com")
        ),
        SocialApp(
            id = "reddit",
            name = "Reddit",
            startUrl = "https://www.reddit.com/",
            hosts = listOf("reddit.com", "redd.it")
        )
    )

    fun byId(id: String): SocialApp? = all.firstOrNull { it.id == id }

    /** Fills the blocker.js template with this app's settings. */
    fun blockerScript(ctx: Context, app: SocialApp): String {
        val template = ctx.assets.open("blocker.js").bufferedReader().use { it.readText() }
        return template
            .replace("__PATHS__", JSONArray(app.blockedPaths).toString())
            .replace("__HOME__", JSONObject.quote(app.startUrl))
            .replace("__CSS__", JSONObject.quote(app.hideCss))
    }
}
