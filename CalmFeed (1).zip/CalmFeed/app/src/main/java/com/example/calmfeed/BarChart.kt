package com.example.calmfeed

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.TypedValue
import android.view.View

/** Tiny bar chart: one bar per day, oldest on the left. */
class BarChart(context: Context) : View(context) {

    var values: List<Int> = emptyList()
    var labels: List<String> = emptyList()

    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF1B4332.toInt() }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF555555.toInt()
        textAlign = Paint.Align.CENTER
        textSize = TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_SP, 11f, resources.displayMetrics
        )
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (values.isEmpty()) return

        val maxValue = (values.maxOrNull() ?: 1).coerceAtLeast(1)
        val slot = width.toFloat() / values.size
        val barWidth = slot * 0.55f
        val labelH = dpToPx(20).toFloat()
        val topPad = dpToPx(18).toFloat()
        val chartH = height - labelH - topPad
        val radius = dpToPx(4).toFloat()
        val gap = dpToPx(4).toFloat()

        for (i in values.indices) {
            val h = chartH * values[i] / maxValue
            val left = i * slot + (slot - barWidth) / 2
            val top = topPad + chartH - h
            val centerX = left + barWidth / 2

            canvas.drawRoundRect(left, top, left + barWidth, topPad + chartH, radius, radius, barPaint)
            canvas.drawText(Fmt.short(values[i]), centerX, top - gap, textPaint)
            val label = labels.getOrNull(i) ?: ""
            canvas.drawText(label, centerX, height - gap, textPaint)
        }
    }
}
