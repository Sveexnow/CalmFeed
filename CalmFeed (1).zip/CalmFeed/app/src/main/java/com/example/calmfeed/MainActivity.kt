package com.example.calmfeed

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class MainActivity : Activity() {

    private val green = 0xFF1B4332.toInt()
    private val card = 0xFFF1F3F2.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    // Rebuilt every time the screen comes back so the numbers are fresh.
    override fun onResume() {
        super.onResume()
        build()
    }

    private fun build() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dpToPx(20), dpToPx(24), dpToPx(20), dpToPx(32))
        }

        root.addView(text("CalmFeed", 30f, bold = true, color = green))
        root.addView(text("Your social apps, minus the endless scroll.", 14f, color = 0xFF666666.toInt()))

        // --- Today + limit -------------------------------------------------
        val total = Store.totalSeconds(this)
        val limit = Store.limitMinutes(this)

        val todayBox = box().apply { setMargins(this, top = 20) }
        todayBox.addView(text("Today", 13f, color = 0xFF666666.toInt()))
        todayBox.addView(text(Fmt.long(total), 34f, bold = true))
        todayBox.addView(
            text(
                if (limit > 0) "of your ${formatMinutes(limit)} daily limit" else "No daily limit set",
                14f, color = 0xFF666666.toInt()
            )
        )

        val limitRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dpToPx(12), 0, 0)
        }
        limitRow.addView(smallButton("-15") { Store.setLimitMinutes(this, maxOf(0, limit - 15)); build() })
        limitRow.addView(smallButton("+15") { Store.setLimitMinutes(this, limit + 15); build() })
        limitRow.addView(smallButton("No limit") { Store.setLimitMinutes(this, 0); build() })
        todayBox.addView(limitRow)
        root.addView(todayBox)

        // --- Last 7 days ---------------------------------------------------
        root.addView(text("Last 7 days", 16f, bold = true).apply { setMargins(this, top = 24) })
        val chart = BarChart(this)
        val fmt = SimpleDateFormat("EEEEE", Locale.getDefault())
        val values = ArrayList<Int>()
        val labels = ArrayList<String>()
        for (daysAgo in 6 downTo 0) {
            values.add(Store.totalSeconds(this, daysAgo))
            val cal = Calendar.getInstance()
            cal.add(Calendar.DAY_OF_YEAR, -daysAgo)
            labels.add(fmt.format(cal.time))
        }
        chart.values = values
        chart.labels = labels
        root.addView(
            chart,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpToPx(150))
        )

        // --- Apps ----------------------------------------------------------
        root.addView(text("Open an app", 16f, bold = true).apply { setMargins(this, top = 16) })
        for (app in Apps.all) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = rounded(card)
                setPadding(dpToPx(16), dpToPx(16), dpToPx(16), dpToPx(16))
                isClickable = true
                setOnClickListener {
                    startActivity(Intent(this@MainActivity, BrowserActivity::class.java).putExtra("app", app.id))
                }
            }
            val name = text(app.name, 17f, bold = true)
            row.addView(name, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(text(Fmt.long(Store.seconds(this, app.id)) + " today", 14f, color = 0xFF666666.toInt()))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dpToPx(8)
            root.addView(row, lp)
        }

        root.addView(
            text(
                "Instagram, YouTube and Facebook open with Reels and Shorts removed. " +
                    "Time is counted only while an app is open here, and stays on your phone.",
                12f, color = 0xFF888888.toInt()
            ).apply { setMargins(this, top = 20) }
        )

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun formatMinutes(m: Int): String =
        if (m >= 60) "${m / 60}h" + (if (m % 60 > 0) " ${m % 60}m" else "") else "${m}m"

    private fun text(s: String, sp: Float, bold: Boolean = false, color: Int = Color.BLACK) =
        TextView(this).apply {
            text = s
            setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun box() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(card)
        setPadding(dpToPx(16), dpToPx(16), dpToPx(16), dpToPx(16))
    }

    private fun smallButton(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { rightMargin = dpToPx(8) }
    }

    private fun rounded(color: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dpToPx(14).toFloat()
    }

    private fun setMargins(v: View, top: Int) {
        val lp = v.layoutParams as? LinearLayout.LayoutParams
            ?: LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dpToPx(top)
        v.layoutParams = lp
    }
}
