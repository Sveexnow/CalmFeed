package com.example.calmfeed

import android.content.Context
import android.content.res.Resources
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/** Stores time spent per app per day, and the daily limit, on the phone only. */
object Store {
    private fun prefs(c: Context) = c.getSharedPreferences("calmfeed", Context.MODE_PRIVATE)

    private fun dayKey(daysAgo: Int): String {
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, -daysAgo)
        return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
    }

    fun addSeconds(c: Context, appId: String, seconds: Int) {
        val key = "u|${dayKey(0)}|$appId"
        val p = prefs(c)
        p.edit().putInt(key, p.getInt(key, 0) + seconds).apply()
    }

    fun seconds(c: Context, appId: String, daysAgo: Int = 0): Int =
        prefs(c).getInt("u|${dayKey(daysAgo)}|$appId", 0)

    fun totalSeconds(c: Context, daysAgo: Int = 0): Int =
        Apps.all.sumOf { seconds(c, it.id, daysAgo) }

    /** Daily limit in minutes across all apps. 0 means no limit. */
    fun limitMinutes(c: Context): Int = prefs(c).getInt("limit_min", 60)

    fun setLimitMinutes(c: Context, minutes: Int) {
        prefs(c).edit().putInt("limit_min", minutes.coerceIn(0, 600)).apply()
    }

    fun limitReached(c: Context): Boolean {
        val limit = limitMinutes(c)
        return limit > 0 && totalSeconds(c) >= limit * 60
    }
}

object Fmt {
    fun long(sec: Int): String {
        val h = sec / 3600
        val m = (sec % 3600) / 60
        return when {
            h > 0 -> "${h}h ${m}m"
            m > 0 -> "${m}m"
            else -> "${sec}s"
        }
    }

    fun short(sec: Int): String {
        if (sec <= 0) return ""
        val h = sec / 3600
        val m = (sec % 3600) / 60
        return when {
            h > 0 -> "${h}h${m}"
            m > 0 -> "${m}m"
            else -> "<1m"
        }
    }
}

fun dpToPx(v: Int): Int = (v * Resources.getSystem().displayMetrics.density).toInt()
