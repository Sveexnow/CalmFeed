package com.example.calmfeed

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Opens one site in a WebView, removes the short-video feeds with
 * assets/blocker.js, counts the time, and stops when the daily limit is hit.
 */
class BrowserActivity : Activity() {

    private lateinit var app: SocialApp
    private lateinit var web: WebView
    private lateinit var status: TextView
    private lateinit var overlay: LinearLayout

    private val handler = Handler(Looper.getMainLooper())
    private var running = false
    private var lastTick = 0L
    private var pendingMs = 0L
    private var limitHit = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val found = Apps.byId(intent.getStringExtra("app") ?: "")
        if (found == null) {
            finish()
            return
        }
        app = found

        buildUi()
        configureWebView()

        if (Store.limitReached(this)) {
            showLimitScreen()
        } else {
            web.loadUrl(app.startUrl)
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(0xFF1B4332.toInt())
            setPadding(dpToPx(12), dpToPx(10), dpToPx(12), dpToPx(10))
        }
        val home = TextView(this).apply {
            text = "‹ Home"
            setTextColor(Color.WHITE)
            textSize = 16f
            setPadding(0, 0, dpToPx(16), 0)
            setOnClickListener { finish() }
        }
        status = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 13f
            gravity = Gravity.CENTER
        }
        val reload = TextView(this).apply {
            text = "↻"
            setTextColor(Color.WHITE)
            textSize = 20f
            setPadding(dpToPx(16), 0, 0, 0)
            setOnClickListener { web.reload() }
        }
        bar.addView(home)
        bar.addView(status, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(reload)
        root.addView(bar)

        web = WebView(this)
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        overlay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.WHITE)
            setPadding(dpToPx(32), dpToPx(32), dpToPx(32), dpToPx(32))
            visibility = android.view.View.GONE
            isClickable = true
        }
        overlay.addView(TextView(this).apply {
            text = "Daily limit reached"
            textSize = 24f
            setTextColor(0xFF1B4332.toInt())
            gravity = Gravity.CENTER
        })
        overlay.addView(TextView(this).apply {
            text = "You've used your time for today. Go do something else — you've earned it."
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, dpToPx(12), 0, dpToPx(20))
        })
        overlay.addView(Button(this).apply {
            text = "Back to CalmFeed"
            isAllCaps = false
            setOnClickListener { finish() }
        })

        val frame = FrameLayout(this)
        frame.addView(root, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        frame.addView(overlay, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(frame)
    }

    private fun configureWebView() {
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        // Drop the "; wv" marker so sites serve their normal mobile pages.
        s.userAgentString = s.userAgentString.replace("; wv", "")

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)

        val script = Apps.blockerScript(this, app)

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                val scheme = uri.scheme ?: return true
                if (scheme != "http" && scheme != "https") return true // ignore app deep links

                if (!app.isAllowedHost(uri.host)) {
                    // Links to other sites open in your normal browser.
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, uri))
                    } catch (e: Exception) {
                        // no app can open it; ignore
                    }
                    return true
                }
                if (app.isBlockedPath(uri.path ?: "")) {
                    view.loadUrl(app.startUrl)
                    return true
                }
                return false
            }

            // Fires for in-page navigation too (YouTube and Instagram are single-page apps).
            override fun doUpdateVisitedHistory(view: WebView, url: String?, isReload: Boolean) {
                val path = url?.let { Uri.parse(it).path } ?: return
                if (app.isBlockedPath(path)) {
                    view.post { view.loadUrl(app.startUrl) }
                }
            }

            override fun onPageCommitVisible(view: WebView, url: String?) {
                view.evaluateJavascript(script, null)
            }

            override fun onPageFinished(view: WebView, url: String?) {
                view.evaluateJavascript(script, null)
            }
        }
    }

    // --- Time tracking ------------------------------------------------------

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            accumulate()
            updateStatus()
            enforceLimit()
            handler.postDelayed(this, 1000)
        }
    }

    private fun accumulate() {
        val now = SystemClock.elapsedRealtime()
        pendingMs += now - lastTick
        lastTick = now
        val secs = (pendingMs / 1000).toInt()
        if (secs > 0) {
            Store.addSeconds(this, app.id, secs)
            pendingMs -= secs * 1000L
        }
    }

    private fun updateStatus() {
        val total = Fmt.long(Store.totalSeconds(this))
        val limit = Store.limitMinutes(this)
        status.text = if (limit > 0) "${app.name} · $total of ${limit}m today" else "${app.name} · $total today"
    }

    private fun enforceLimit() {
        if (!limitHit && Store.limitReached(this)) showLimitScreen()
    }

    private fun showLimitScreen() {
        limitHit = true
        web.loadUrl("about:blank")
        overlay.visibility = android.view.View.VISIBLE
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
        running = true
        lastTick = SystemClock.elapsedRealtime()
        updateStatus()
        handler.post(tick)
    }

    override fun onPause() {
        if (running) accumulate()
        running = false
        handler.removeCallbacks(tick)
        web.onPause()
        CookieManager.getInstance().flush()
        super.onPause()
    }

    override fun onDestroy() {
        if (::web.isInitialized) web.destroy()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (!limitHit && web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
